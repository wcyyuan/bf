#import <Preferences/PSSwitchTableCell.h>
#import <Preferences/PSSpecifier.h>

@interface ATLApplicationSubtitleSwitchCell : PSSwitchTableCell
@end